# clear
nodemon main.js
# nodemon main.js  --dev true

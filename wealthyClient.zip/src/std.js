const log = console.log
const logwarn = console.warn
const logerror = console.error

export { log, logwarn, logerror }
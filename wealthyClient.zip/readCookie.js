const fs = require("fs")

var dataDirPath = "C:/Users/s/Desktop/vva/vva/"

async function listFolder(dirPath = dataDirPath) {
    let folders = fs.readdirSync(dirPath, { withFileTypes: true });
    return folders;
}

function getJson(dirName) {
    // console.log("dirName", dirName, dirName.isDirectory());
    if (dirName.isDirectory()) {
        let file = `${dataDirPath}${dirName.name}/FBFastCheck/Cookies_JSON.txt`;
        let json = JSON.parse(fs.readFileSync(file))
        return json;
    }
    return null
}

function jsonToCookie(json) {
    return json.map(v => `${v.name}=${v.value}`).join(";")
}


listFolder()
    .then(folders => folders.map(async folder => {

        let json = getJson(folder)
        if (json) {
            let cookie = await jsonToCookie(json)
            
            return cookie;
        } else return null;
    }))
    .then(cookies => {
        Promise.all(cookies).then(cookies => {

            let fd = fs.openSync(dataDirPath + "cookies.txt", 'a+');
            fs.appendFileSync(fd, cookies.filter(v => v != null).join("\n"), 'utf8')
        })

    })

